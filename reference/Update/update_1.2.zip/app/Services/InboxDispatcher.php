<?php

namespace App\Services;

use App\Enums\WaProvider;
use App\Models\InboxMessage;
use App\Models\SystemSetting;
use App\Models\WaProviderConfig;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Dedicated dispatcher for team-inbox bubbles (`inbox_messages` table).
 * Separate from WhatsAppDispatcher so the inbox surface and the
 * campaign / broadcast surface can evolve independently without
 * stepping on each other.
 *
 * What this handles:
 *   - send($msg)               — text or media outbound (Baileys/WABA/Twilio)
 *   - reaction($msg, $emoji)   — emoji reaction on a bubble
 *   - pin($msg, $pin, $time)   — pin / unpin (Baileys only)
 *   - star($msg, $star)        — star / unstar (Baileys only)
 *
 * What this DOESN'T do (use WhatsAppDispatcher for those):
 *   - scheduled sends (campaigns, broadcasts, drips)
 *   - bulk campaign delivery
 *
 * Internally calls the same Node bridge endpoints as the legacy
 * dispatcher — no Node-side duplication required.
 */
class InboxDispatcher
{
    public function send(InboxMessage $msg, string $platform = 'W'): array
    {
        // Platform-wide emergency halt gate — admin can pause ALL outbound
        // sends from /admin/security → Danger zone. Reads the cached
        // platform.emergency_send_halt flag (one DB read per request).
        if (\App\Support\SendGate::halted()) {
            Log::warning('[INBOX-DISPATCH] refused — emergency halt engaged', [
                'msg_id'    => $msg->id,
                'to_number' => $msg->to_number,
            ]);
            return [
                'ok'        => false,
                'platform'  => 'halted',
                'local_only'=> true,
                'error'     => 'Platform emergency halt is engaged. Resume sends from /admin/security → Danger zone.',
            ];
        }

        // WhatsApp guardrails (admin's /admin/security rate caps + content
        // filters). No-op unless mode is monitor/enforce; monitor only logs.
        // Fail-open. Workspace id resolves via the conversation (InboxMessage
        // has no direct workspace_id column).
        try {
            $wsId = (int) \DB::table('conversations')->where('id', $msg->conversation_id)->value('workspace_id');
            \App\Support\SendGate::screen($wsId ?: null, (string) $msg->body, ['msg_id' => $msg->id, 'to' => $msg->to_number]);
        } catch (\Throwable $e) {
            Log::warning('[INBOX-DISPATCH] refused by security guardrail', ['msg_id' => $msg->id, 'reason' => $e->getMessage()]);
            return [
                'ok'         => false,
                'platform'   => 'blocked',
                'local_only' => true,
                'error'      => $e->getMessage(),
            ];
        }

        // Plan limit — block outbound sends if the workspace has hit
        // its monthly_messages_limit. Counts messages already dispatched
        // this calendar month for this workspace (both inbox replies
        // and campaign/broadcast/flow sends — anything that landed an
        // outbound row).
        $this->guardMonthlyMessagesLimit($msg);

        $resolved = $this->resolveProvider($msg, $platform);
        Log::info('[INBOX-DISPATCH] entry', [
            'msg_id'      => $msg->id,
            'user_id'     => $msg->user_id,
            'from_number' => $msg->from_number,
            'to_number'   => $msg->to_number,
            'platform'    => $platform,
            'resolved'    => $resolved->value,
        ]);

        // Stamp the resolved engine on the message row so analytics +
        // /devices KPI cards can filter by `provider` directly instead
        // of joining through device→workspace→engine. Idempotent — only
        // sets it if currently null.
        if (empty($msg->provider) && \Illuminate\Support\Facades\Schema::hasColumn('inbox_messages', 'provider')) {
            try {
                $msg->forceFill(['provider' => $resolved->value])->saveQuietly();
            } catch (\Throwable $e) {
                Log::debug('[INBOX-DISPATCH] provider stamp failed: ' . $e->getMessage());
            }
        }

        // Plan-gated outbound footer. Operator-typed replies + their
        // attached media captions get the footer appended in-place
        // before transport dispatch — keeps WABA, Baileys, and Twilio
        // identical without changing each transport's payload builder.
        // Templates from the inbox composer's template picker have
        // their own template_id flow and never reach this method.
        //
        // Real-time translation FIRST — translate an operator-typed reply into
        // the customer's pinned language before the footer + transport. No-op
        // when translation is off, no language is pinned, or the body is already
        // in the customer's language (AI/keyword replies generated natively in
        // it). Mutates $msg->body in-memory; the agent's original is preserved
        // in translated_body for the thread view.
        try {
            app(\App\Services\Inbox\ConversationTranslationService::class)->translateOutbound($msg);
        } catch (\Throwable $e) { /* never block a send */ }

        $this->applyBrandingFooter($msg);

        // Align the in-memory provider to the engine we ACTUALLY resolved JUST
        // for the duration of the dispatch — dispatchNode() reads $msg->provider
        // to tell Node which channel to use, and resolveProvider() may have
        // fallen THROUGH a disabled/disconnected pin (msg.provider or the
        // conversation.provider reply-on-same-channel fallback) to a different
        // engine. We RESTORE it immediately after: the attribute is backed by a
        // persisted column and inbox callers flush the model after dispatch
        // (TeamInboxController update()), so leaving it dirty would overwrite the
        // operator's stored pin with the fallback engine + corrupt analytics.
        $providerBeforeDispatch = $msg->provider;
        $msg->provider = $resolved->value;

        try {
            // Single dispatch path: WABA + Baileys both go through Node so
            // PHP never holds Meta credentials. Node fetches the per-phone
            // settings (token + phone_id) from /api/whatsapp-settings and
            // routes to Meta Cloud or Baileys sock accordingly.
            $result = match ($resolved) {
                WaProvider::Twilio  => $this->dispatchTwilio($msg),
                default             => $this->dispatchNode($msg),  // baileys + waba
            };
        } finally {
            // Restore the original (DB-synced) provider so no later save()
            // persists the transient alignment over the record's stored pin —
            // in finally so the restore holds even if a future dispatch refactor
            // lets an exception escape.
            $msg->provider = $providerBeforeDispatch;
        }

        Log::info('[INBOX-DISPATCH] result', [
            'msg_id'      => $msg->id,
            'ok'          => $result['ok'] ?? null,
            'platform'    => $result['platform'] ?? null,
            'provider_id' => $result['provider_id'] ?? null,
            'local_only'  => $result['local_only'] ?? null,
            'error'       => $result['error'] ?? null,
        ]);
        return $result;
    }

    public function reaction(InboxMessage $msg, string $emoji): array
    {
        $platform = optional($msg->conversation)->platform ?? 'W';
        $resolved = $this->resolveProvider($msg, $platform);
        if ($resolved !== WaProvider::Baileys) {
            return ['ok' => true, 'platform' => $resolved->value, 'local_only' => true, 'error' => null];
        }
        [$serverUrl, $from] = $this->resolveDevicePhone($msg);
        if ($serverUrl === '' || $from === '') {
            return ['ok' => false, 'error' => 'No connected device or server url'];
        }

        $meta        = is_array($msg->meta) ? $msg->meta : [];
        $waMessageId = (string) ($meta['wa_message_id'] ?? '');
        $targetJid   = (string) ($meta['target_jid']    ?? '');
        $isInbound   = $msg->direction === 'in';
        $reactTo     = $isInbound ? ($msg->from_number ?: null) : $msg->to_number;

        $fromEnc = rawurlencode(preg_replace('/\D+/', '', $from) ?: $from);
        $url = rtrim($serverUrl, '/') . '/api/send-reaction/' . $fromEnc;

        try {
            $res = Http::timeout(10)->acceptJson()->asJson()->post($url, [
                'targetPhoneNumber' => $reactTo,
                'targetJid'         => $targetJid !== '' ? $targetJid : null,
                'targetMessageId'   => $waMessageId !== '' ? $waMessageId : null,
                'fromMe'            => !$isInbound,
                'emoji'             => $emoji,
            ]);
            return ['ok' => $res->successful(), 'error' => $res->successful() ? null : $res->body()];
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    public function pin(InboxMessage $msg, bool $pin = true, int $durationSeconds = 86400): array
    {
        return $this->messageAction($msg, '/api/pin-message/', [
            'pin'      => $pin,
            'duration' => $durationSeconds,
        ], 'INBOX-PIN');
    }

    public function star(InboxMessage $msg, bool $star = true): array
    {
        return $this->messageAction($msg, '/api/star-message/', [
            'star' => $star,
        ], 'INBOX-STAR');
    }

    /**
     * Delete-for-everyone (revoke). Per itsukichan/baileys README §
     * "Deleting Messages (for everyone)":
     *
     *   await sock.sendMessage(jid, { delete: msg.key })
     *
     * which surfaces a "This message was deleted" placeholder on the
     * recipient's WhatsApp. We POST the same shape to the Node bridge
     * which builds the {id, remoteJid, fromMe} key from the args.
     */
    public function deleteForEveryone(InboxMessage $msg): array
    {
        return $this->messageAction($msg, '/api/delete-message/', [
            // no extra fields — messageAction already passes
            // targetMessageId, targetJid, fromMe. Node does the rest.
        ], 'INBOX-DELETE');
    }

    /**
     * Edit-for-everyone. Per itsukichan/baileys README § "Editing Messages":
     *
     *   await sock.sendMessage(jid, { text: 'updated text', edit: msg.key })
     *
     * The recipient's WhatsApp shows the new text with an "Edited" tag.
     * WhatsApp enforces a 15-minute window on their end; the caller is
     * expected to validate the window before invoking this.
     */
    public function editForEveryone(InboxMessage $msg, string $newText): array
    {
        return $this->messageAction($msg, '/api/edit-message/', [
            'newText' => $newText,
        ], 'INBOX-EDIT');
    }

    // -----------------------------------------------------------------
    // Internals — provider routing + per-provider builders.
    // -----------------------------------------------------------------

    private function resolveProvider(InboxMessage $msg, string $platformHint): WaProvider
    {
        $workspaceId = optional($msg->conversation)->workspace_id;
        if (!$workspaceId && $msg->conversation_id) {
            $workspaceId = \App\Models\Conversation::query()->whereKey($msg->conversation_id)->value('workspace_id');
        }
        if (!$workspaceId && $msg->user_id) {
            $workspaceId = \App\Models\User::query()->whereKey($msg->user_id)->value('current_workspace_id');
        }
        if (!$workspaceId) {
            $workspaceId = optional(auth()->user())->current_workspace_id;
        }

        $allowed = SystemSetting::get('allowed_send_methods', ['baileys', 'waba', 'twilio']);
        $allowed = is_array($allowed) ? $allowed : [$allowed];

        // Phase 4 — per-record provider pin WINS. If Phase 3 already stamped
        // inbox_messages.provider, honour it (admin-allowed + actually enabled
        // on this workspace) so a multi-engine workspace's reply leaves on the
        // exact engine the operator picked rather than the workspace default.
        if (!empty($msg->provider)) {
            $pinned = WaProvider::tryFrom((string) $msg->provider);
            if ($pinned
                && in_array($pinned->value, $allowed, true)
                && \App\Services\WorkspaceEngine::isEngineEnabled($workspaceId, $pinned->value)
            ) {
                return $pinned;
            }
        }

        // Reply-on-same-channel — when this message has no explicit provider,
        // an inbox reply should still leave on the CONVERSATION'S channel
        // (the engine the inbound arrived on), which Phase 3 stamped into
        // conversations.provider. Prefer that over the workspace default.
        // Legacy conversations have an empty provider => skipped, so
        // single-engine inboxes fall through unchanged.
        $convProvider = optional($msg->conversation)->provider;
        if (empty($convProvider) && $msg->conversation_id) {
            $convProvider = \App\Models\Conversation::query()->whereKey($msg->conversation_id)->value('provider');
        }
        if (!empty($convProvider)) {
            $convPinned = WaProvider::tryFrom((string) $convProvider);
            if ($convPinned
                && in_array($convPinned->value, $allowed, true)
                && \App\Services\WorkspaceEngine::isEngineEnabled($workspaceId, $convPinned->value)
            ) {
                return $convPinned;
            }
        }

        if ($workspaceId) {
            $cfg = WaProviderConfig::query()->primaryForWorkspace($workspaceId)->first();
            if ($cfg && $cfg->isConnected() && in_array($cfg->provider, $allowed, true)) {
                return $cfg->providerEnum();
            }
        }
        if ($platformHint !== '' && strtoupper($platformHint) !== 'W') {
            $hinted = WaProvider::fromLegacyCode($platformHint);
            if (in_array($hinted->value, $allowed, true)) return $hinted;
        }
        $adminDefault = SystemSetting::get('default_send_method', 'baileys');
        $resolved = WaProvider::tryFrom((string) $adminDefault) ?? WaProvider::Baileys;
        if (!in_array($resolved->value, $allowed, true) && !empty($allowed)) {
            $resolved = WaProvider::tryFrom((string) $allowed[0]) ?? WaProvider::Baileys;
        }
        return $resolved;
    }

    /**
     * Returns [$serverUrl, $devicePhone]. Picks the device the conversation
     * belongs to (NOT the customer phone — that would crash Node, whose
     * clients dict is keyed by device phone).
     */
    private function resolveDevicePhone(InboxMessage $msg): array
    {
        $serverUrl = '';
        $from = '';
        $workspaceId = $msg->user_id ? \App\Models\User::query()->whereKey($msg->user_id)->value('current_workspace_id') : null;
        $cfg = null;
        if ($workspaceId) {
            $cfg = WaProviderConfig::query()->primaryForWorkspace($workspaceId)->first();
            if ($cfg) {
                $creds = $cfg->creds();
                $serverUrl = (string) ($creds['server_url'] ?? '');
                // NOTE: do NOT seed $from from the workspace PRIMARY config here.
                // On a multi-device / multi-engine workspace the primary is
                // often a DIFFERENT number (or engine, e.g. WABA) than the
                // device THIS conversation is paired to. Seeding it caused
                // Node to be told "Baileys send from the primary number",
                // find no ready socket for it, and return CLIENT NOT READY.
                // The conversation's own device (below) wins; the primary is
                // only a last-resort fallback.
            }
        }
        if ($serverUrl === '') $serverUrl = (string) (SystemSetting::get('baileys_server_url') ?: env('SERVER_URL', ''));

        // 1) Outbound: from_number IS the device this chat is paired to —
        //    set by TeamInboxController::reply / AiAgentService from the
        //    conversation's device. This MUST win so the send leaves on the
        //    same number the customer is talking to.
        if ($msg->direction === 'out' && $msg->from_number) {
            $from = preg_replace('/\D+/', '', (string) $msg->from_number) ?: '';
        }
        // 2) Else resolve via the conversation's device_id.
        if ($from === '') {
            $conv = $msg->conversation ?: ($msg->conversation_id
                ? \App\Models\Conversation::query()->find($msg->conversation_id)
                : null);
            if ($conv && $conv->device_id) {
                $device = \App\Models\Device::query()->find($conv->device_id);
                if ($device) $from = preg_replace('/\D+/', '', (string) ($device->country_code . $device->phone_number));
            }
        }
        // 3) Fallback: the workspace primary config phone (single-engine
        //    workspaces land here and behave exactly as before).
        if ($from === '' && $cfg) {
            $creds = $cfg->creds();
            $from = (string) ($cfg->phone_number ?: ($creds['phone_number'] ?? ''));
        }
        if ($from === '' && $msg->user_id) {
            // Queue/service context — no authed user, so we pass the
            // message's workspace_id explicitly. Falls back to user_id
            // for legacy NULL-workspace rows.
            $device = \App\Models\Device::query()->forWorkspace($msg->workspace_id ?? null, $msg->user_id)->where('status', 'connected')->orderByDesc('id')->first();
            if ($device) $from = preg_replace('/\D+/', '', (string) ($device->country_code . $device->phone_number));
        }
        return [$serverUrl, $from];
    }

    private function dispatchNode(InboxMessage $msg): array
    {
        [$serverUrl, $from] = $this->resolveDevicePhone($msg);
        Log::info('[INBOX-BAILEYS] resolved', ['msg_id' => $msg->id, 'server_url' => $serverUrl, 'from_number' => $from]);
        if (rtrim($serverUrl, '/') === '') {
            return $this->localOnly('W', 'SERVER_URL not set and workspace has no Baileys config');
        }
        if ($from === '') {
            return ['ok' => false, 'platform' => 'W', 'provider_id' => null, 'local_only' => false, 'error' => 'No connected device — pair one at /devices first.'];
        }

        [$path, $payload] = $this->buildNodeRequest($msg, $from);
        // Phase 4 — forward the resolved per-message engine so Node routes by
        // it (explicit provider wins; absent => Node's legacy heuristic).
        // Omitted when empty so single-engine inboxes keep Node's old path.
        if (!empty($msg->provider)) {
            $payload['provider'] = (string) $msg->provider;
        }
        $url = rtrim($serverUrl, '/') . $path;
        Log::info('[INBOX-BAILEYS] →', ['msg_id' => $msg->id, 'url' => $url, 'to' => $payload['targetPhoneNumber'] ?? null]);

        try {
            $hasMedia = isset($payload['file_base64']) && $payload['file_base64'];
            $res = Http::timeout($hasMedia ? 60 : 20)->acceptJson()->asJson()->post($url, $payload);
            Log::info('[INBOX-BAILEYS] ←', ['msg_id' => $msg->id, 'status' => $res->status(), 'body' => mb_substr($res->body(), 0, 500)]);
            if ($res->successful()) {
                return [
                    'ok'          => true,
                    'platform'    => 'W',
                    'provider_id' => $res->json('messageId') ?? $res->json('id'),
                    'local_only'  => false,
                    'error'       => null,
                ];
            }
            $err = $res->json('error') ?? $res->json('details') ?? $res->json('message') ?? ('HTTP ' . $res->status());
            return ['ok' => false, 'platform' => 'W', 'provider_id' => null, 'local_only' => false, 'error' => is_string($err) ? $err : json_encode($err)];
        } catch (\Throwable $e) {
            return ['ok' => false, 'platform' => 'W', 'provider_id' => null, 'local_only' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Pick the Node endpoint + payload based on message shape. The inbox
     * surface uses three endpoints:
     *   - text only  → /api/send-message/<phone>
     *   - media+caption → /api/send-media-message/<phone>
     *   - media only → /api/send-media-only/<phone>
     *
     * We don't use /api/schedule-message or /api/send-location here —
     * inbox bubbles are always immediate, and location bubbles arrive as
     * inbound only (operator can't send a location).
     */
    private function buildNodeRequest(InboxMessage $msg, string $from): array
    {
        $fromEnc = rawurlencode(preg_replace('/\D+/', '', $from) ?: $from);
        $meta    = is_array($msg->meta) ? $msg->meta : [];

        if ($msg->media_path) {
            // Read from the active media disk (cloud when enabled, else local).
            $mediaDisk = media_storage();
            $hasFile   = $mediaDisk->exists($msg->media_path);
            $b64       = $hasFile ? base64_encode($mediaDisk->get($msg->media_path)) : null;
            $url       = media_url($msg->media_path);
            $mimeReal  = $hasFile ? ($mediaDisk->mimeType($msg->media_path) ?: 'application/octet-stream') : 'application/octet-stream';
            $base     = basename($msg->media_path);
            $origName = str_contains($base, '__') ? substr($base, strpos($base, '__') + 2) : $base;

            $shared = [
                'targetPhoneNumber' => $msg->to_number,
                'file'              => $url,
                'file_base64'       => $b64,
                'filetype'          => $mimeReal,
                'fileName'          => $origName,
            ];
            // Voice-note flag — when meta.ptt is true, ask Node to send as
            // push-to-talk so WhatsApp renders the round play-button bubble.
            if (!empty($meta['ptt'])) {
                $shared['ptt']   = true;
                $shared['voice'] = true; // alias for older bridge builds
                if ($msg->media_type === 'audio') {
                    $shared['filetype'] = 'audio/ogg; codecs=opus';
                }
            }
            if (!empty($meta['target_jid'])) {
                $shared['targetJid'] = (string) $meta['target_jid'];
            }
            if ($msg->body) {
                return ['/api/send-media-message/' . $fromEnc, $shared + ['caption' => (string) $msg->body]];
            }
            return ['/api/send-media-only/' . $fromEnc, $shared];
        }

        $payload = [
            'targetPhoneNumber' => $msg->to_number,
            'message'           => (string) $msg->body,
        ];
        if (!empty($meta['target_jid'])) {
            $payload['targetJid'] = (string) $meta['target_jid'];
        }
        // Plumb template-shaped meta (buttons / header / footer) through to
        // Node so interactive sends from the team-inbox composer survive.
        // Without this, an operator picking an approved template from the
        // composer dropdown lost quick-reply / CTA buttons silently — only
        // the body text reached the customer.
        return ['/api/send-message/' . $fromEnc, $this->mergeButtonsFooterMeta($payload, $meta)];
    }

    /**
     * Mirror of WhatsAppDispatcher::mergeButtonsFooter for the team-inbox
     * path so template replies from the inbox composer carry their buttons
     * / header / footer into Node's interactive-message branch. Kept local
     * to InboxDispatcher to avoid a cross-class call dependency.
     */
    private function mergeButtonsFooterMeta(array $payload, array $meta): array
    {
        if (empty($meta)) return $payload;

        if (!empty($meta['buttons']) && is_array($meta['buttons'])) {
            $payload['buttons'] = array_values(array_filter(array_map(function ($b) {
                if (!is_array($b)) return null;
                $type  = (string) ($b['type']  ?? 'quick_reply');
                $text  = (string) ($b['text']  ?? '');
                $value = (string) ($b['value'] ?? '');
                $url   = (string) ($b['url']   ?? '');
                if ($type === 'visit_website' && $url === '') $url = $value;
                if ($type === 'call_phone' && !empty($b['country_code'])) {
                    $cc = preg_replace('/\D+/', '', (string) $b['country_code']);
                    $vd = preg_replace('/\D+/', '', $value);
                    if ($cc && $vd && !str_starts_with($vd, $cc)) $value = $cc . $vd;
                }
                return ['type' => $type, 'text' => $text, 'value' => $value, 'url' => $url];
            }, $meta['buttons'])));
        }
        if (!empty($meta['footer'])) $payload['footer'] = (string) $meta['footer'];
        if (!empty($meta['header'])) $payload['title']  = (string) $meta['header'];
        return $payload;
    }

    private function dispatchMetaCloud(InboxMessage $msg): array
    {
        // Multi-tenant: resolve THIS workspace's WABA config first
        // (per-workspace access_token + phone_number_id). Without this
        // every workspace's inbox reply went out from the same global
        // env-configured Meta number, which collapses multi-tenant.
        $workspaceId = (int) (optional($msg->conversation)->workspace_id ?? 0);
        $token = '';
        $phoneId = '';
        if ($workspaceId > 0) {
            $cfg = WaProviderConfig::query()->primaryForWorkspace($workspaceId)->first()
                ?? WaProviderConfig::query()->where('workspace_id', $workspaceId)
                    ->where('provider', 'waba')->orderByDesc('connected_at')->first();
            if ($cfg) {
                $creds   = $cfg->creds();
                $meta    = is_array($cfg->meta_json) ? $cfg->meta_json : [];
                $token   = (string) ($creds['access_token'] ?? '');
                $phoneId = (string) ($meta['phone_number_id'] ?? '');
            }
        }
        // No env fallback — credentials live in DB only (per-workspace
        // wa_provider_configs). If a workspace has no WABA config yet,
        // the send fails loudly via `localOnly` below; admin must
        // connect a Meta number at /devices first. This keeps secrets
        // out of process env where they could leak via phpinfo / error
        // pages / shell exports.
        $version = (string) \App\Models\SystemSetting::get('waba_graph_api_version', 'v23.0');
        if ($token === '' || $phoneId === '') {
            return $this->localOnly('WB', 'No WABA token + phone_number_id for this workspace. Connect a WABA account at /devices.');
        }

        $to = preg_replace('/\D+/', '', (string) $msg->to_number);
        $body = $this->buildCloudPayload($msg, $to);

        try {
            $res = Http::withToken($token)
                ->acceptJson()
                ->timeout(10)
                ->post("https://graph.facebook.com/{$version}/{$phoneId}/messages", $body);
            if ($res->successful()) {
                return [
                    'ok'          => true,
                    'platform'    => 'WB',
                    'provider_id' => $res->json('messages.0.id'),
                    'local_only'  => false,
                    'error'       => null,
                ];
            }
            $err = $res->json('error.message') ?? ('HTTP ' . $res->status());
            return ['ok' => false, 'platform' => 'WB', 'provider_id' => null, 'local_only' => false, 'error' => $err];
        } catch (\Throwable $e) {
            return ['ok' => false, 'platform' => 'WB', 'provider_id' => null, 'local_only' => false, 'error' => $e->getMessage()];
        }
    }

    private function buildCloudPayload(InboxMessage $msg, string $to): array
    {
        $meta = is_array($msg->meta) ? $msg->meta : [];

        // Template path — the inbox composer set template_id, so the
        // outbound MUST be a type:template payload. Without this Meta
        // rejects with error 131047 ("re-engagement message") any time
        // the recipient hasn't messaged us in 24h. This was the #1 WABA
        // blocker per the 2026-05-24 audit.
        if (!empty($meta['template_id']) && !empty($meta['template_name'])) {
            $components = [];
            // Body component — pull positional vars out of the resolved
            // body. We have `$msg->body` already substituted; for Meta
            // we send the substituted strings as parameters (Meta also
            // substitutes server-side using the approved template's
            // `{{1}}, {{2}}…` slots — sending pre-substituted text in
            // type=text params works for both behaviors).
            $body = (string) $msg->body;
            // Tokenise on whitespace if the template has placeholders —
            // for now we send the whole body as a single `text` param
            // when the approved template has one positional slot; if
            // the template has multiple, this falls back to {{1}} = body.
            // Templates without placeholders need empty components.
            if (preg_match_all('/\{\{\s*\d+\s*\}\}/', $body, $matches) && count($matches[0]) > 0) {
                $components[] = [
                    'type' => 'body',
                    'parameters' => array_map(
                        fn () => ['type' => 'text', 'text' => $body],
                        $matches[0]
                    ),
                ];
            }
            return [
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => 'template',
                'template'          => array_filter([
                    'name'       => (string) $meta['template_name'],
                    'language'   => ['code' => (string) ($meta['template_language'] ?? 'en')],
                    'components' => $components,
                ], fn ($v) => $v !== null && $v !== []),
            ];
        }

        if ($msg->media_path) {
            $mediaType = $msg->media_type ?: 'document';
            $url = media_url($msg->media_path);
            $mediaPayload = ['link' => $url];
            // WABA audio is auto-rendered as voice-note for opus; caption
            // not supported on audio.
            if ($mediaType !== 'audio' && $msg->body) {
                $mediaPayload['caption'] = $msg->body;
            }
            return [
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => $mediaType,
                $mediaType          => array_filter($mediaPayload),
            ];
        }

        // Plain text with optional buttons (interactive). Interactive
        // is used when the operator composed quick-reply buttons inline.
        if (!empty($meta['buttons']) && is_array($meta['buttons'])) {
            $buttons = array_slice($meta['buttons'], 0, 3);
            $interactive = [
                'type'   => 'button',
                'body'   => ['text' => mb_substr((string) $msg->body, 0, 1024)],
                'action' => [
                    'buttons' => array_map(function ($b, $i) {
                        return [
                            'type'  => 'reply',
                            'reply' => [
                                'id'    => mb_substr((string) ($b['id']    ?? "btn_$i"), 0, 256),
                                'title' => mb_substr((string) ($b['title'] ?? $b['text'] ?? "Option ".($i + 1)), 0, 20),
                            ],
                        ];
                    }, $buttons, array_keys($buttons)),
                ],
            ];
            if (!empty($meta['header'])) $interactive['header'] = ['type' => 'text', 'text' => mb_substr((string) $meta['header'], 0, 60)];
            if (!empty($meta['footer'])) $interactive['footer'] = ['text' => mb_substr((string) $meta['footer'], 0, 60)];
            return [
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => 'interactive',
                'interactive'       => $interactive,
            ];
        }

        return [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'text',
            'text'              => ['body' => (string) $msg->body],
        ];
    }

    private function dispatchTwilio(InboxMessage $msg): array
    {
        // Resolve creds per-workspace from WaProviderConfig (mirrors the
        // chat-path dispatcher). Previously this method read `env()` only,
        // collapsing multi-tenant Twilio: every workspace's inbox reply
        // billed the platform's Twilio account. Now each workspace's
        // saved Twilio number/token actually drives its inbox sends.
        $sid = $token = $from = '';
        $sandbox = false;
        $workspaceId = (int) (optional($msg->conversation)->workspace_id ?? 0);
        if ($workspaceId > 0) {
            $cfg = WaProviderConfig::query()
                ->where('workspace_id', $workspaceId)
                ->where('provider', 'twilio')
                ->where('status', WaProviderConfig::STATUS_CONNECTED)
                ->first();
            if ($cfg) {
                $creds   = $cfg->creds();
                $sid     = (string) ($creds['account_sid']  ?? '');
                $token   = (string) ($creds['auth_token']   ?? '');
                $from    = (string) ($creds['from_number']  ?? $cfg->phone_number ?? '');
                $sandbox = (bool)   ($creds['sandbox']      ?? false);
            }
        }
        if ($sid === '')   $sid   = (string) \App\Models\SystemSetting::get('twilio_account_sid', env('TWILIO_ACCOUNT_SID', ''));
        if ($token === '') $token = (string) \App\Models\SystemSetting::get('twilio_auth_token', env('TWILIO_AUTH_TOKEN', ''));
        if ($from === '')  $from  = (string) \App\Models\SystemSetting::get('twilio_whatsapp_number', env('TWILIO_WHATSAPP_NUMBER', ''));
        if ($sid === '' || $token === '' || $from === '') {
            return $this->localOnly('T', 'Twilio creds missing for this workspace — connect Twilio at /devices.');
        }
        if ($sandbox) $from = '14155238886';

        // Twilio's `whatsapp:+E164` format — `+` is required by spec.
        $to       = 'whatsapp:+' . preg_replace('/\D+/', '', (string) $msg->to_number);
        $fromBare = preg_replace('/\D+/', '', (string) $from);
        $payload  = ['From' => 'whatsapp:+' . $fromBare, 'To' => $to];

        // StatusCallback — see WhatsAppDispatcher::dispatchTwilio note.
        // Without this Twilio never POSTs delivered/read events back.
        $appBase = rtrim((string) config('app.url'), '/');
        if ($appBase !== '') {
            $payload['StatusCallback'] = $appBase . '/api/twilio/status';
        }

        // Template reply: if the operator picked a template that has a
        // registered Twilio ContentSid, ship it as a ContentSid send so
        // marketing/utility/auth categories remain compliant. The meta
        // shape mirrors what BroadcastsController / ChatController build
        // (`meta.template_vars` + `meta.otp_code`).
        $meta = is_array($msg->meta) ? $msg->meta : [];
        $contentSid = null;
        if (!empty($meta['template_id'])) {
            $tpl = \App\Models\WaTemplate::find((int) $meta['template_id']);
            $contentSid = $tpl?->twilio_content_sid ? trim((string) $tpl->twilio_content_sid) : null;
        }

        if ($contentSid) {
            $payload['ContentSid']       = $contentSid;
            $payload['ContentVariables'] = $this->buildTwilioContentVariablesFromMeta($meta);
        } elseif ($msg->media_path) {
            $payload['MediaUrl'] = media_url($msg->media_path);
            if ($msg->body) $payload['Body'] = $msg->body;
        } else {
            $payload['Body'] = (string) $msg->body;
        }

        try {
            $res = Http::withBasicAuth($sid, $token)
                ->asForm()
                ->timeout(10)
                ->post("https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json", $payload);
            if ($res->successful()) {
                return ['ok' => true, 'platform' => 'T', 'provider_id' => $res->json('sid'), 'local_only' => false, 'error' => null];
            }
            $err = $res->json('message') ?? ('HTTP ' . $res->status());
            return ['ok' => false, 'platform' => 'T', 'provider_id' => null, 'local_only' => false, 'error' => $err];
        } catch (\Throwable $e) {
            return ['ok' => false, 'platform' => 'T', 'provider_id' => null, 'local_only' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Build Twilio ContentVariables JSON from a Message::meta array.
     * Positional keys only — Twilio's substitution engine doesn't read
     * named keys. See WhatsAppDispatcher::buildTwilioContentVariables for
     * the matching implementation on the user-side chat path.
     */
    private function buildTwilioContentVariablesFromMeta(array $meta): string
    {
        $vars = is_array($meta['template_vars'] ?? null) ? $meta['template_vars'] : [];
        if (!empty($meta['otp_code']) && !isset($vars['1'])) {
            $vars['1'] = (string) $meta['otp_code'];
        }
        $out = [];
        foreach ($vars as $k => $v) {
            $out[(string) $k] = is_scalar($v) ? (string) $v : json_encode($v);
        }
        return json_encode($out, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '{}';
    }

    /**
     * Shared plumbing for pin/star — both go to Baileys via the same payload
     * shape (target message id + jid + fromMe). WABA + Twilio silently no-op.
     */
    private function messageAction(InboxMessage $msg, string $path, array $extra, string $tag): array
    {
        $platform = optional($msg->conversation)->platform ?? 'W';
        $resolved = $this->resolveProvider($msg, $platform);
        if ($resolved !== WaProvider::Baileys) {
            return ['ok' => true, 'platform' => $resolved->value, 'local_only' => true];
        }

        [$serverUrl, $from] = $this->resolveDevicePhone($msg);
        if ($from === '' || $serverUrl === '') {
            Log::warning("[{$tag}] no from/server", ['from' => $from, 'server' => $serverUrl, 'msg_id' => $msg->id]);
            return ['ok' => false, 'error' => 'No connected device or server url'];
        }

        $meta        = is_array($msg->meta) ? $msg->meta : [];
        $waMessageId = (string) ($meta['wa_message_id'] ?? '');
        $targetJid   = (string) ($meta['target_jid']    ?? '');
        $isInbound   = $msg->direction === 'in';
        $reactTo     = $isInbound ? ($msg->from_number ?: null) : $msg->to_number;

        if ($waMessageId === '') {
            return [
                'ok'    => false,
                'error' => 'This message was saved before WhatsApp-id tracking was enabled. Receive a new message and try again.',
            ];
        }

        $fromEnc = rawurlencode(preg_replace('/\D+/', '', $from) ?: $from);
        $url     = rtrim($serverUrl, '/') . $path . $fromEnc;

        $payload = array_merge([
            'targetPhoneNumber' => $reactTo,
            'targetJid'         => $targetJid !== '' ? $targetJid : null,
            'targetMessageId'   => $waMessageId,
            'fromMe'            => !$isInbound,
        ], $extra);

        Log::info("[{$tag}] → POST {$url}", $payload + ['msg_id' => $msg->id]);

        try {
            $res = Http::timeout(10)->acceptJson()->asJson()->post($url, $payload);
            $ok  = $res->successful();
            Log::info("[{$tag}] ← " . $res->status() . ($ok ? ' OK' : ' FAIL'), [
                'msg_id' => $msg->id, 'status' => $res->status(),
                'body'   => mb_substr((string) $res->body(), 0, 500),
            ]);
            return ['ok' => $ok, 'error' => $ok ? null : $res->body()];
        } catch (\Throwable $e) {
            Log::warning("[{$tag}] threw", ['err' => $e->getMessage(), 'msg_id' => $msg->id]);
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Append the plan-gated outbound footer to the operator's reply body
     * (or to a media caption if there's no body). Mutates $msg->body in
     * place — every transport reads from there so we apply once at the
     * top of send() and the three dispatch paths all pick it up.
     * Skipped when:
     *   - there's no body AND no media caption (e.g. pure media bubble)
     *   - the workspace's plan grants remove_branding AND they cleared
     *     the footer (BrandingFooterService::resolve returns null)
     */
    private function applyBrandingFooter(InboxMessage $msg): void
    {
        $workspace = null;
        if ($msg->workspace_id) {
            $workspace = \App\Models\Workspace::find($msg->workspace_id);
        }
        if (!$workspace) return;

        $body = (string) ($msg->body ?? '');
        // Skip pure-media sends with no caption — no body to append to.
        // Media WITH a caption is fine; we'll attach the footer to the caption.
        if ($body === '') return;

        $newBody = \App\Services\BrandingFooterService::appendToBody($body, $workspace);
        if ($newBody !== $body) {
            $msg->body = $newBody;
            // Note: not saved — the dispatcher reads in-memory; the DB
            // row already shows what the operator actually typed.
        }
    }

    private function localOnly(string $platform, string $reason): array
    {
        return [
            'ok'          => true,
            'platform'    => $platform,
            'provider_id' => null,
            'local_only'  => true,
            'error'       => null,
            'reason'      => $reason,
        ];
    }

    /**
     * Resolve the workspace that owns this message and enforce the
     * monthly_messages_limit cap with credit-overflow:
     *   - Under cap → free, no deduction
     *   - Over cap + wallet has credits → deduct 1 credit, allow
     *   - Over cap + wallet at 0 → throw PlanLimitReachedException
     *
     * Counts outbound messages this calendar month across BOTH tables:
     *   - inbox_messages (team-inbox replies, AI-agent, flow sends)
     *   - messages (legacy /chat surface + campaigns + broadcasts)
     */
    private function guardMonthlyMessagesLimit(InboxMessage $msg): void
    {
        $workspaceId = optional($msg->conversation)->workspace_id;
        if (!$workspaceId && $msg->conversation_id) {
            $workspaceId = \App\Models\Conversation::query()->whereKey($msg->conversation_id)->value('workspace_id');
        }
        if (!$workspaceId && $msg->user_id) {
            $workspaceId = \App\Models\User::query()->whereKey($msg->user_id)->value('current_workspace_id');
        }
        if (!$workspaceId) return; // can't enforce without a workspace

        $workspace = \App\Models\Workspace::find($workspaceId);
        if (!$workspace) return;

        $monthStart = now()->startOfMonth();
        $used = \App\Models\InboxMessage::query()
            ->whereHas('conversation', fn ($q) => $q->where('workspace_id', $workspaceId))
            ->where('direction', 'out')
            ->where('created_at', '>=', $monthStart)
            ->count();
        $userIds = \DB::table('workspace_user')->where('workspace_id', $workspaceId)->pluck('user_id');
        if ($userIds->isNotEmpty()) {
            $used += \DB::table('messages')
                ->whereIn('user_id', $userIds)
                ->where('direction', 'out')
                ->where('created_at', '>=', $monthStart)
                ->count();
        }

        // Operator inbox replies are inside the 24h customer-service window →
        // bill as 'service' (priced free by default under per-country pricing,
        // mirroring Meta). No-ops to the flat rate when the flag is OFF.
        \App\Services\OverflowBilling::consumeOne($workspace, $used, null, 'service');
    }
}
